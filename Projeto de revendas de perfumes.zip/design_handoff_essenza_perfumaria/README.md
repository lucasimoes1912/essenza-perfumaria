# Handoff: Essenza — Site de Revenda de Perfumes

## Overview
Loja virtual (protótipo) para a marca "Essenza", revendedora de perfumes. Fluxo completo: Home → Catálogo → Página de Produto → Carrinho/Checkout, com carrinho funcional no front-end.

## About the Design Files
Os arquivos deste pacote (`Essenza.dc.html`, `image-slot.js`) são **referências de design em HTML** — um protótipo mostrando aparência e comportamento pretendidos, não código de produção para copiar diretamente. A tarefa é **recriar este design HTML no ambiente já existente do projeto de destino** (React, Vue, etc.) usando os padrões e bibliotecas estabelecidos — ou, se ainda não houver um projeto, escolher o framework mais adequado e implementar o design ali.

## Fidelity
**High-fidelity (hifi)**: cores, tipografia, espaçamento e interações finais. O layout e os textos devem ser recriados com precisão; os textos de produto são placeholders de exemplo (podem ser substituídos por dados reais).

## Screens / Views

### 1. Home
- Header fixo (sticky), altura ~78px, padding `18px 48px`, fundo branco levemente translúcido com blur, borda inferior 1px `oklch(90% 0.02 90)`.
  - Logo "Essenza": Poppins 800, 26px, gradiente de texto (rosa → azul), clicável (vai para Home).
  - Nav: Home / Catálogo / Sobre (rolagem até seção "Sobre") — Inter 600 15px.
  - Ícone de carrinho: círculo 42px, fundo `oklch(95% 0.015 90)`, badge numérico rosa `oklch(62% 0.20 350)` no canto superior direito quando há itens.
- Hero banner: cartão com `border-radius:28px`, grid 2 colunas (1.1fr/1fr), gradiente `linear-gradient(115deg, oklch(66% 0.19 350), oklch(64% 0.17 230))`, min-height 420px.
  - Selo "Frete grátis acima de R$ 199" — pill translúcida branca.
  - Título Poppins 800 48px, texto branco.
  - Parágrafo 17px, opacidade 0.95.
  - Botão "Ver catálogo": branco, texto rosa escuro, pill, Poppins 700.
  - Slot de imagem à direita preenchendo a altura do card.
- Seção "Compre por categoria": grid de 3 cards (Masculino / Feminino / Unissex), `border-radius:20px`, padding 32px, cada um com bloco de cor de 44px e título Poppins 700 20px. Clique filtra o catálogo pela categoria.
- Seção "Mais vendidos": grid de 4 colunas com cards de produto (ver componente "Product Card" abaixo). Link "Ver todos →" no canto.
- Seção "Sobre a Essenza": card com fundo `oklch(96% 0.015 90)`, `border-radius:28px`, grid 2 colunas (texto + imagem), texto institucional sobre ser revenda autorizada.

### 2. Catálogo
- Título "Catálogo" (Poppins 800 34px) + contagem de resultados.
- Chips de filtro: Todos / Masculino / Feminino / Unissex — pill, estado ativo com fundo preto/texto branco, inativo fundo branco com borda cinza clara.
- Grid 4 colunas de Product Cards (imagem quadrada 1:1, categoria em rosa uppercase, nome Poppins 600 16px, tamanho, preço + botão "+" circular preto para adicionar direto ao carrinho).

### 3. Página de Produto
- Link "← Voltar ao catálogo".
- Grid 2 colunas: imagem grande quadrada (rounded 20px) à esquerda; à direita categoria, nome (Poppins 800 32px), tamanho, preço (800 30px), descrição, stepper de quantidade (pill com − / +), botão "Adicionar ao carrinho" (preto, pill), mensagem de confirmação "✓ Adicionado ao carrinho" em verde.

### 4. Carrinho / Checkout
- Três estados possíveis: vazio, com itens, pedido confirmado.
- **Vazio**: card centralizado com CTA "Ver catálogo".
- **Com itens**: grid 2 colunas.
  - Esquerda: lista de itens (thumb 80x80, nome, tamanho, stepper de quantidade, "Remover" em rosa, subtotal).
  - Direita (resumo, sticky): subtotal, frete (grátis acima de R$199, senão R$15), total, campos "Nome completo" / "Endereço de entrega", seleção de pagamento Pix/Cartão (toggle pill), botão "Finalizar pedido" (preto, pill).
- **Confirmado**: ícone de check, título "Pedido confirmado!", texto de agradecimento, botão "Voltar à loja".

### Product Card (componente reutilizado)
- Fundo branco, `border-radius:18px`, borda 1px `oklch(92% 0.015 90)`.
- Imagem 1:1 no topo (usar `height:auto` junto de `aspect-ratio` para manter proporção real).
- Padding 16px: categoria (rosa, uppercase, 12px), nome (Poppins 600 16px), preço (700 17px).

## Interactions & Behavior
- Navegação entre views é client-side (SPA), sem reload.
- Clique em card de produto → abre página de produto.
- Botão "+" em card do catálogo adiciona 1 unidade ao carrinho sem navegar (usa `stopPropagation`).
- Stepper de quantidade incrementa/decrementa (mínimo 1 na página de produto; item some do carrinho ao chegar a 0).
- Filtro de categoria: clique nas categorias da Home ou nos chips do catálogo atualiza a lista exibida.
- "Finalizar pedido" muda o estado do carrinho para "pedido confirmado" (sem backend real — é só front-end no protótipo).
- Frete grátis calculado automaticamente quando subtotal > R$199.

## State Management
- `view`: 'home' | 'catalog' | 'product' | 'cart'
- `categoryFilter`: 'todos' | 'masculino' | 'feminino' | 'unissex'
- `selectedId`: id do produto aberto
- `qty`: quantidade selecionada na página de produto
- `cart`: mapa `{ productId: quantidade }`
- `orderPlaced`: boolean
- `name`, `address`, `payment`: campos do checkout

## Design Tokens
- **Cores**
  - Fundo: `oklch(98% 0.012 90)` (branco quente)
  - Texto: `oklch(20% 0.02 90)` (quase preto)
  - Acento 1 (rosa/magenta): `oklch(62–68% 0.19–0.20 350)`
  - Acento 2 (azul): `oklch(64–68% 0.16–0.17 220–230)`
  - Cinzas neutros: `oklch(88–96% 0.015–0.02 90)`
- **Tipografia**
  - Títulos: Poppins 600/700/800
  - Corpo: Inter 400/500/600/700
- **Border radius**: 10–12px (inputs/thumbs), 16–20px (cards), 28px (cards de seção grandes), 100px (pills/botões)
- **Espaçamento**: padding de seção 48–96px; gap de grid 24px

## Assets
- Todas as imagens são placeholders (componente de drag-and-drop `image-slot.js`) — precisam ser substituídas por fotos reais dos produtos, banner e foto da loja/equipe.
- Nenhum ícone externo: setas e ícones (carrinho, +/-) são SVGs inline simples.

## Files
- `Essenza.dc.html` — protótipo completo (todas as 4 telas em um único arquivo, com lógica de estado).
- `image-slot.js` — componente auxiliar de placeholder de imagem (apenas para o protótipo; não precisa ser portado).
